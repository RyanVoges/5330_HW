pandoc -s -t beamer -V theme:default -V colortheme:dove Chapter3.md -o Chapter3.pdf
